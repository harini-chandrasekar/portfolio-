import { useState } from 'react';
import { Menu, X, Mail, Phone, MapPin, Github, Linkedin, ExternalLink, Code2, Briefcase, GraduationCap, Award, Target } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    setIsMenuOpen(false);
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Code2 className="w-6 h-6 text-cyan-600" />
              <span className="text-xl font-bold text-slate-800">Harini C</span>
            </div>

            <div className="hidden md:flex space-x-8">
              {['Home', 'About', 'Experience', 'Projects', 'Skills', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className={`text-sm font-medium transition-colors ${
                    activeSection === item.toLowerCase()
                      ? 'text-cyan-600'
                      : 'text-slate-600 hover:text-cyan-600'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-slate-600"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-4 py-4 space-y-3">
              {['Home', 'About', 'Experience', 'Projects', 'Skills', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="block w-full text-left text-slate-600 hover:text-cyan-600 font-medium"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      <section id="home" className="pt-24 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block px-4 py-2 bg-cyan-100 text-cyan-700 rounded-full text-sm font-medium mb-4">
                Full Stack Developer
              </div>
              <h1 className="text-5xl md:text-6xl font-bold text-slate-800 mb-4">
                Hi, I'm <span className="text-cyan-600">Harini C</span>
              </h1>
              <p className="text-xl text-slate-600 mb-6">
                Passionate about building scalable web applications with React.js, Node.js, and modern technologies.
              </p>
              <div className="flex flex-wrap gap-4 mb-8">
                <a
                  href="mailto:c.harini1109@gmail.com"
                  className="flex items-center space-x-2 px-6 py-3 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors"
                >
                  <Mail className="w-5 h-5" />
                  <span>Get in Touch</span>
                </a>
                <a
                  href="https://github.com/harini-chandrasekar"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 px-6 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-900 transition-colors"
                >
                  <Github className="w-5 h-5" />
                  <span>View GitHub</span>
                </a>
              </div>
              <div className="flex items-center space-x-6 text-slate-600">
                <div className="flex items-center space-x-2">
                  <MapPin className="w-5 h-5" />
                  <span>India</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-5 h-5" />
                  <span>+91-7604987764</span>
                </div>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-2xl transform rotate-6"></div>
                <div className="relative bg-white p-8 rounded-2xl shadow-xl">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center">
                        <Code2 className="w-6 h-6 text-cyan-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">Clean Code</div>
                        <div className="text-sm text-slate-500">Best Practices</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Briefcase className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">3+ Projects</div>
                        <div className="text-sm text-slate-500">Production Ready</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <Target className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">Problem Solver</div>
                        <div className="text-sm text-slate-500">Result Oriented</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-slate-800 mb-4 text-center">About Me</h2>
          <div className="w-20 h-1 bg-cyan-600 mx-auto mb-12"></div>
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <p className="text-lg text-slate-600 leading-relaxed mb-6">
                I'm a passionate Full Stack Developer with expertise in building modern web applications.
                Currently pursuing my Bachelor's in Information Technology, I combine academic knowledge
                with practical experience from multiple internships.
              </p>
              <p className="text-lg text-slate-600 leading-relaxed mb-6">
                I specialize in React.js, Node.js, and RESTful APIs, with a strong focus on creating
                responsive, user-friendly interfaces and robust backend systems. I'm also an active member
                of the ChennaiPy Community and regularly participate in coding competitions.
              </p>
              <div className="flex space-x-4">
                <a
                  href="https://github.com/harini-chandrasekar"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-slate-800 text-white rounded-lg flex items-center justify-center hover:bg-slate-900 transition-colors"
                >
                  <Github className="w-6 h-6" />
                </a>
                <a
                  href="https://linkedin.com/in/harini-c-31b9b7256/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-blue-600 text-white rounded-lg flex items-center justify-center hover:bg-blue-700 transition-colors"
                >
                  <Linkedin className="w-6 h-6" />
                </a>
              </div>
            </div>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <GraduationCap className="w-6 h-6 text-cyan-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">Education</h3>
                  <p className="text-slate-600">Bachelor's in Information Technology</p>
                  <p className="text-sm text-slate-500">Currently Pursuing</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Briefcase className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">Experience</h3>
                  <p className="text-slate-600">Multiple Internships</p>
                  <p className="text-sm text-slate-500">HCL Technologies, Redback IT Solutions</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Award className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">Community</h3>
                  <p className="text-slate-600">ChennaiPy Active Member</p>
                  <p className="text-sm text-slate-500">Technical Event Organizer</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="experience" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-slate-800 mb-4 text-center">Professional Experience</h2>
          <div className="w-20 h-1 bg-cyan-600 mx-auto mb-12"></div>
          <div className="space-y-8">
            <div className="bg-white rounded-xl shadow-md p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-slate-800">System Engineer Intern</h3>
                  <p className="text-cyan-600 font-medium">HCL Technologies</p>
                </div>
                <div className="text-slate-500 text-sm">India</div>
              </div>
              <p className="text-slate-600 mb-4">
                Worked on enterprise-level systems, contributing to backend development and system integration projects.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">System Design</span>
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">Backend Development</span>
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">Integration</span>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-slate-800">Full Stack Developer Intern</h3>
                  <p className="text-cyan-600 font-medium">Redback IT Solutions</p>
                </div>
                <div className="text-slate-500 text-sm">India</div>
              </div>
              <p className="text-slate-600 mb-4">
                Developed full-stack web applications using React.js and Node.js, implementing RESTful APIs and database solutions.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">React.js</span>
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">Node.js</span>
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">RESTful APIs</span>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-slate-800">Web Development Intern</h3>
                  <p className="text-cyan-600 font-medium">SEET, Bangalore</p>
                </div>
                <div className="text-slate-500 text-sm">Bangalore</div>
              </div>
              <p className="text-slate-600 mb-4">
                Built responsive web applications and contributed to frontend development using modern web technologies.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">HTML/CSS</span>
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">JavaScript</span>
                <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">Responsive Design</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-slate-800 mb-4 text-center">Featured Projects</h2>
          <div className="w-20 h-1 bg-cyan-600 mx-auto mb-12"></div>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow">
              <div className="p-8">
                <div className="w-16 h-16 bg-cyan-600 rounded-lg flex items-center justify-center mb-4">
                  <Code2 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-3">Full-Stack Social Networking Platform</h3>
                <p className="text-slate-600 mb-6">
                  A comprehensive social networking application with user authentication, real-time messaging,
                  post creation, and interactive features. Built with React.js frontend and Node.js backend.
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="px-3 py-1 bg-white text-slate-700 rounded-full text-sm">React.js</span>
                  <span className="px-3 py-1 bg-white text-slate-700 rounded-full text-sm">Node.js</span>
                  <span className="px-3 py-1 bg-white text-slate-700 rounded-full text-sm">MongoDB</span>
                  <span className="px-3 py-1 bg-white text-slate-700 rounded-full text-sm">Express</span>
                </div>
                <button className="flex items-center space-x-2 text-cyan-600 hover:text-cyan-700 font-medium">
                  <span>View Project</span>
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow">
              <div className="p-8">
                <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mb-4">
                  <Briefcase className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-3">Console Application for User Management</h3>
                <p className="text-slate-600 mb-6">
                  A robust console-based application for managing user data with CRUD operations,
                  authentication, and role-based access control. Implemented with Python and MySQL.
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="px-3 py-1 bg-white text-slate-700 rounded-full text-sm">Python</span>
                  <span className="px-3 py-1 bg-white text-slate-700 rounded-full text-sm">MySQL</span>
                  <span className="px-3 py-1 bg-white text-slate-700 rounded-full text-sm">Authentication</span>
                </div>
                <button className="flex items-center space-x-2 text-cyan-600 hover:text-cyan-700 font-medium">
                  <span>View Project</span>
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-slate-800 mb-4 text-center">Technical Skills</h2>
          <div className="w-20 h-1 bg-cyan-600 mx-auto mb-12"></div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Languages</h3>
              <div className="space-y-3">
                {['Python', 'JavaScript', 'C', 'HTML', 'CSS'].map((skill) => (
                  <div key={skill} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-cyan-600 rounded-full"></div>
                    <span className="text-slate-600">{skill}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Frameworks</h3>
              <div className="space-y-3">
                {['React.js', 'Node.js', 'Express'].map((skill) => (
                  <div key={skill} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                    <span className="text-slate-600">{skill}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Databases</h3>
              <div className="space-y-3">
                {['MySQL', 'Firebase', 'MongoDB'].map((skill) => (
                  <div key={skill} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    <span className="text-slate-600">{skill}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Tools & Cloud</h3>
              <div className="space-y-3">
                {['Git', 'Docker', 'VS Code', 'AWS'].map((skill) => (
                  <div key={skill} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                    <span className="text-slate-600">{skill}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-cyan-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Let's Work Together</h2>
          <p className="text-xl text-cyan-100 mb-12">
            I'm always open to discussing new projects, creative ideas, or opportunities to be part of your vision.
          </p>
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <a
              href="mailto:c.harini1109@gmail.com"
              className="bg-white/10 backdrop-blur-md rounded-xl p-6 hover:bg-white/20 transition-colors"
            >
              <Mail className="w-8 h-8 text-white mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-2">Email</h3>
              <p className="text-cyan-100 text-sm">c.harini1109@gmail.com</p>
            </a>
            <a
              href="tel:+917604987764"
              className="bg-white/10 backdrop-blur-md rounded-xl p-6 hover:bg-white/20 transition-colors"
            >
              <Phone className="w-8 h-8 text-white mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-2">Phone</h3>
              <p className="text-cyan-100 text-sm">+91-7604987764</p>
            </a>
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
              <MapPin className="w-8 h-8 text-white mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-2">Location</h3>
              <p className="text-cyan-100 text-sm">India</p>
            </div>
          </div>
          <div className="flex justify-center space-x-4">
            <a
              href="https://github.com/harini-chandrasekar"
              target="_blank"
              rel="noopener noreferrer"
              className="w-14 h-14 bg-white text-cyan-600 rounded-full flex items-center justify-center hover:bg-cyan-50 transition-colors"
            >
              <Github className="w-6 h-6" />
            </a>
            <a
              href="https://linkedin.com/in/harini-c-31b9b7256/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-14 h-14 bg-white text-cyan-600 rounded-full flex items-center justify-center hover:bg-cyan-50 transition-colors"
            >
              <Linkedin className="w-6 h-6" />
            </a>
          </div>
        </div>
      </section>

      <footer className="bg-slate-900 text-white py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-slate-400">
            &copy; {new Date().getFullYear()} Harini C. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
